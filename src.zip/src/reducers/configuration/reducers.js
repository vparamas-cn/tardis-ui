import { SOURCE_LIST_REQUEST, SOURCE_LIST_SUCCESS, SOURCE_LIST_FAILURE, ACTION_SOURCE_REQUEST, ACTION_SOURCE_SUCCESS, ACTION_SOURCE_FAILURE, ACTION_RESET, FILTER_PAGINATION } from './actions'

const initialState = {
    isLoading: false,
    isactionLoading: false,
    data: [],
    filterData: [],
    filter: {},
    page: 1,
    size: 5,
    totalPage:1,
    totalElements:5,
    actiondata:{message:"",data:{}},
    pageBound:{current:1,upperbound:1,lowerbound:0}
}

const sourceReducer = (state = initialState, action) => {

    switch (action.type) {
        case SOURCE_LIST_REQUEST: {
            return {
                ...state,
                isLoading: true,
                data:[]
            }
        }
        case SOURCE_LIST_SUCCESS: {
            return {
                ...state,
                isLoading: false,
                data: state.data.concat(action.payroll.data.source.results),
                totalElements: action.payroll.data.source.totalElements,
            }
        }
        case SOURCE_LIST_FAILURE: {
            return {
                ...state,
                isLoading: false
            }
        }
        case ACTION_SOURCE_REQUEST: {
            return {
                ...state,
                isactionLoading: true,
                actiondata:{ message: "",data :{} }
            }
        }
        case ACTION_SOURCE_SUCCESS: {
            var err = action.payroll.errors;
            return {
                ...state,
                isactionLoading: false,
                actiondata:{ message: err?"error":"success",data :err ? err[0].message.substring(0,40) :"source added successfully!!"}
            }
        }
        case ACTION_SOURCE_FAILURE: {
            var err = action.payroll.errors;
            return {
                ...state,
                isactionLoading: false,
                actiondata:{ message: "error",data :err ? err[0].message.substring(0,40) :"API Failed!!"}
            }
        }
        case ACTION_RESET: {
            return {
                ...state,
                isactionLoading: false,
                actiondata:{ message: "",data :""}
            }
        }
        case FILTER_PAGINATION: {
            var data  = action.payroll;
            return{
                ...state,
                filter:  data.filter ? data.filter: {},
                filterData: data.filterData? data.filterData:[],
                page:data.page ? data.page: 1,
                size:data.size ? data.size: 5,
                totalPage:data.totalPage ? data.totalPage:1,
                totalElements:data.totalElements ? data.totalElements:5,
                pageBound: data.pageBound ? data.pageBound:{current:1,upperbound:1,lowerbound:0}
            }
        }
        default: return state;
    }

}

export default sourceReducer;