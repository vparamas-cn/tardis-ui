import { all, call, put, select, takeLatest } from 'redux-saga/effects';
import { SOURCE_LIST_REQUEST, SOURCE_LIST_FAILURE, SOURCE_LIST_SUCCESS, ACTION_SOURCE_REQUEST, ACTION_SOURCE_SUCCESS, ACTION_SOURCE_FAILURE} from './actions';
import { fetch } from '../../assets/constant'
import query from '../../assets/constant/query'

export function* fetchList(action) {
    let response;
    try {
        let hasrow = false; let size = 1000;
        do{
        response = yield call(fetch,query.source(size));
        const data = yield response.data;
        size += 1000;
        yield put({ type: SOURCE_LIST_SUCCESS, payroll: data });
        }
        while(hasrow)
    }
    catch (error) {
        yield put({ type: SOURCE_LIST_FAILURE, payroll:response.errors });
    }
}

export function* actionHandler(action) {
    try {
        const response = yield call(fetch,action.payroll);
        const data = yield response.data;
        yield put({ type: ACTION_SOURCE_SUCCESS, payroll: data });
    }
    catch (error) {
        yield put({ type: ACTION_SOURCE_FAILURE });
    }
}



export function* loadList() {
    yield takeLatest(SOURCE_LIST_REQUEST, fetchList);
    yield takeLatest(ACTION_SOURCE_REQUEST, actionHandler);
}

export default function* mainSaga() {
    yield all([loadList()]);
}