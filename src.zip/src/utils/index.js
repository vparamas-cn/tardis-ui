import { ACTION_RESET } from "../reducers/configuration/actions";
export const filterdata = (data, params) =>{
    const paramscheck = (e) =>{
        for(var y in Object.keys(params)){
            if(Array.isArray(params[y]))
            {
                for(var z in params[y])
                {
                   return e[y] === z;
                }
            }
            else{
               return e[y] === params[y];
            }
        }

    }
    let result = data.fliter((e,i)=>{
        return paramscheck(e)
    })
    return result;
}

export const paginationFilter = (dataSource) => {
    let {totalElements, size, data, filter ,page} = dataSource;
    let totalPage = Math.ceil(totalElements / size);
    var resultdata=data;
    if(totalPage < page){
        page = 1
    }
    let sizecheck = page * size;
    let pagecheck = (sizecheck - size)
    if(Object.keys(filter).length>0)
    {
        resultdata = filterdata(resultdata,filter);
    }
    resultdata = resultdata.slice(pagecheck, sizecheck);
    let pageBound;
    if(totalPage > 5)
    {
        pageBound={current:5,upperbound:5,lowerbound:0}
    }
    else{
        pageBound={current:totalPage,upperbound:totalPage,lowerbound:0}
    }
    return {
        filterData: resultdata,
        filter: filter,
        page: page,
        size: size,
        totalPage:totalPage,
        totalElements:totalElements,
        pageBound:pageBound
    }
} 

export const alert = (classlist,dispatch,data) =>{
      dispatch({type:ACTION_RESET})
      var x = document.getElementById("snackbar");
      x.className = "show " + classlist;
      x.innerHTML =data.actiondata.data
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}